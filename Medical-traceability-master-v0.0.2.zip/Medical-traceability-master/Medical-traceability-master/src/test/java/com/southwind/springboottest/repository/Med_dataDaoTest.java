package com.southwind.springboottest.repository;

import com.southwind.springboottest.dao.Med_dataDao;
import com.southwind.springboottest.entity.Med_data;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

@SpringBootTest
@RunWith(SpringRunner.class)
public class Med_dataDaoTest {

    @Autowired
    Med_dataDao med_dataDao;

    @Test
    public void saveTest()
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        med_dataDao.save(new Med_data("人参","西藏",100,formattedDate,formattedDate));
    }

    @Test
    public void findAllTest()
    {
        List<Med_data> list=med_dataDao.findAll();
        System.out.println(list);
    }

    @Test
    public void DeleteByIDTest()
    {

        med_dataDao.deleteById(1);
    }

    @Test
    public void UpdateAndFindByIdTest()
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        Med_data med_data=med_dataDao.findById(2);
        med_data.setAmount(5000);
        med_data.setOut_time(formattedDate);
        med_dataDao.Update(med_data);
    }

    @Test
    public void InUpdateTest()
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        Med_data med_data=med_dataDao.findById(2);
        med_data.setIn_time(formattedDate);
        med_dataDao.InUpdate(med_data);
    }

    @Test
    public void OutUpdateTest()
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        Med_data med_data=med_dataDao.findById(3);
        med_data.setOut_time(formattedDate);
        med_dataDao.OutUpdate(med_data);
    }


}
