package com.southwind.springboottest.controller;

import com.southwind.springboottest.dao.Med_dataDao;
import com.southwind.springboottest.entity.Med_data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/medicine")
public class Med_dataHandler {

    @Autowired
    private Med_dataDao med_dataDao;

    @GetMapping("/findAll")
    public List<Med_data> findAll(){
        return med_dataDao.findAll();
    }

    @PostMapping("/save")
    public String save(@RequestBody Med_data med_data){
        med_dataDao.save(med_data);
        return "true";
    }

    @GetMapping("/findById/{id}")
    public Med_data findById(@PathVariable("id") Integer id){
        return med_dataDao.findById(id);
    }

    @PutMapping("/update")
    public String update(@RequestBody Med_data med_data){
        med_dataDao.Update(med_data);
        return "true";
    }

    @DeleteMapping("/deleteById/{id}")
    public void deleteById(@PathVariable("id") Integer id){
        med_dataDao.deleteById(id);
    }

    /**
     * 药材的入库变动，实现库存数量与入库时间的更新
     * @param id
     * @param modify
     * @return
     */
    @PatchMapping(path="in/{id}",consumes = "application/json")
    public String In_Modify(@PathVariable("id")Integer id,@RequestBody Med_data modify)
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        Med_data med_data=med_dataDao.findById(id);
        if(modify.getAmount()!=null)
        {
            med_data.setAmount((med_data.getAmount()+modify.getAmount()));
        }
        med_data.setIn_time(formattedDate);
        med_dataDao.InUpdate(med_data);
        return "true";
    }

    /**
     * 药材的出库变动，实现库存数量与出库时间的更新
     * @param id
     * @param modify
     * @return
     */
    @PatchMapping(path="out/{id}",consumes = "application/json")
    public String Out_Modify(@PathVariable("id")Integer id,@RequestBody Med_data modify)
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        Med_data med_data=med_dataDao.findById(id);
        if(modify.getAmount()!=null)
        {
            med_data.setAmount((med_data.getAmount()-modify.getAmount()));
            if(med_data.getAmount()<0)
            {
                return "false";
            }
        }
        med_data.setOut_time(formattedDate);
        med_dataDao.OutUpdate(med_data);
        return "true";
    }
}
