package com.southwind.springboottest.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Medicine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Integer farmer_id;

    private Integer producer_id;

    private String name;

    private String category;

    private String purch_time;

    private long tra_code;

    private Integer amount;

    private String In_time;

    private String Out_time;

    public Medicine(Integer farmer_id, Integer producer_id, String name, String category, String purch_time, Integer amount, String in_time) {
        this.farmer_id = farmer_id;
        this.producer_id = producer_id;
        this.name = name;
        this.category = category;
        this.purch_time = purch_time;
        this.amount = amount;
        In_time = in_time;
    }
}
