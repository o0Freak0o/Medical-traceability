package com.southwind.springboottest.service.impl;

import com.southwind.springboottest.dao.MedicineMapper;
import com.southwind.springboottest.entity.Medicine;
import com.southwind.springboottest.page.MybatisPageHelper;
import com.southwind.springboottest.page.PageRequest;
import com.southwind.springboottest.page.PageResult;
import com.southwind.springboottest.service.MedicineService;
import com.southwind.springboottest.utils.Tra_codeUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;

@Service
public class MedicineServiceImpl implements MedicineService {

    @Resource
    public MedicineMapper medicineMapper;

    @Override
    public int OutUpdate(Medicine out_med) {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        Medicine medicine = medicineMapper.findById(out_med.getId());
        if(medicine.getAmount()!=null)
        {
            medicine.setAmount((medicine.getAmount()-out_med.getAmount()));
            if(medicine.getAmount()<0)
            {
                return 0;
            }
        }
        medicine.setOut_time(formattedDate);
        return Update(medicine);
    }

    @Override
    public int InUpdate(Medicine in_med) {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        in_med.setIn_time(formattedDate);
        in_med.setTra_code(Tra_codeUtils.code());
        if(in_med.getAmount()==null)
        {
            return 0;
        }
        if(in_med.getName()==null)
        {
            return 0;
        }
        if(in_med.getCategory()==null)
        {
            return 0;
        }
        if(in_med.getPurch_time()==null)
        {
            return 0;
        }
        if(in_med.getProducer_id()==null)
        {
            return 0;
        }
        if(in_med.getFarmer_id()==null)
        {
            return 0;
        }
        return medicineMapper.save(in_med);
    }

    @Override
    public Medicine findById(Integer id) {
        Medicine medicine= medicineMapper.findById(id);
        return medicine;
    }

    @Override
    public List<Medicine> findAll() {
        List<Medicine> medicines=medicineMapper.findAll();
        return medicines;
    }

    @Override
    public int deleteById(Integer id) {
        return medicineMapper.deleteById(id);
    }

    @Override
    public int Update(Medicine medicine) {
        Medicine update = medicineMapper.findById(medicine.getId());
        if(medicine.getName()!=null)
        {
            update.setName(medicine.getName());
        }
        if(medicine.getAmount()!=null)
        {
            update.setAmount(medicine.getAmount());
        }
        if(medicine.getCategory()!=null)
        {
            update.setCategory(medicine.getCategory());
        }
        if(medicine.getFarmer_id()!=null)
        {
            update.setFarmer_id(medicine.getFarmer_id());
        }
        if(medicine.getProducer_id()!=null)
        {
            update.setProducer_id(medicine.getProducer_id());
        }
        if(medicine.getPurch_time()!=null)
        {
            update.setPurch_time(medicine.getPurch_time());
        }
        if(medicine.getIn_time()!=null)
        {
            update.setIn_time(medicine.getIn_time());
        }
        if(medicine.getOut_time()!=null)
        {
            update.setOut_time(medicine.getOut_time());
        }
        return medicineMapper.Update(update);
    }

    @Override
    public PageResult findPage(PageRequest pageRequest) {
        Object label = pageRequest.getParam("label");
        if(label != null) {
            return MybatisPageHelper.findPage(pageRequest,medicineMapper,"findPageByLabel", label);
        }
        return MybatisPageHelper.findPage(pageRequest,medicineMapper);
    }

    @Override
    public Medicine findByTra_code(long tra_code) {
        return medicineMapper.findByTra_code(tra_code);
    }
}
