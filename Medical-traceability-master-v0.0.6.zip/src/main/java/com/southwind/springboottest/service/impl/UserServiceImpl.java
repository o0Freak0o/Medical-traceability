package com.southwind.springboottest.service.impl;

import com.southwind.springboottest.dao.UserMapper;
import com.southwind.springboottest.entity.User;
import com.southwind.springboottest.page.MybatisPageHelper;
import com.southwind.springboottest.page.PageRequest;
import com.southwind.springboottest.page.PageResult;
import com.southwind.springboottest.service.RoleService;
import com.southwind.springboottest.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

@Service
public class UserServiceImpl implements UserService {
    
    @Resource
    UserMapper userMapper;

    @Resource
    RoleService roleService;

    @Override
    public User findById(Integer id) {
        return userMapper.findById(id);
    }

    @Override
    public User findByName(String name) {
        return userMapper.findByName(name);
    }

    @Override
    public List<User> findAll() {
        return userMapper.findAll();
    }

    @Override
    public int deleteById(Integer id) {
        return userMapper.deleteById(id);
    }

    @Override
    public String findRoleByName(String name) {
        return roleService.findById(userMapper.findByName(name).getRole_id()).getName();
    }

    @Override
    public int save(User user) {
        return userMapper.save(user);
    }

    @Override
    public int Update(User user) {
        User update = userMapper.findById(user.getId());
        if(user.getName()!=null)
        {
            update.setName(user.getName());
        }
        if(user.getNickName()!=null)
        {
            update.setNickName(user.getNickName());
        }
        if(user.getRole_id()!=null)
        {
            update.setRole_id(user.getRole_id());
        }
        if(user.getPassword()!=null)
        {
            update.setPassword(user.getPassword());
        }
        if(user.getSalt()!=null)
        {
            update.setSalt(user.getSalt());
        }
        if(user.getMobile()!=null)
        {
            update.setMobile(user.getMobile());
        }
        if(user.getEmail()!=null)
        {
            update.setEmail(user.getEmail());
        }

        return userMapper.Update(update);
    }

    @Override
    public PageResult findPage(PageRequest pageRequest) {
        Object label = pageRequest.getParam("label");
        if(label != null) {
            return MybatisPageHelper.findPage(pageRequest,userMapper,"findPageByLabel", label);
        }
        return MybatisPageHelper.findPage(pageRequest,userMapper);
    }

    @Override
    public int Login(User user) {
        if(Objects.equals(user.getPassword(), userMapper.findByName(user.getName()).getPassword()))
        {
            return 1;
        }
        return 0;
    }
}
