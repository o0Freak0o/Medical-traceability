package com.southwind.springboottest.repository;

import com.southwind.springboottest.entity.Medicine;
import com.southwind.springboottest.service.MedicineService;
import com.southwind.springboottest.utils.DigestUtils;
import org.apache.ibatis.annotations.Many;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
@RunWith(SpringRunner.class)
public class DigestTest {

    @Autowired
    MedicineService medicineService;

    @Test
    public void digest()
    {
        Medicine medicine1=medicineService.findById(1);
        Medicine medicine2=medicineService.findById(2);
        System.out.println(DigestUtils.DigestProducer(medicine1));
        System.out.println(DigestUtils.DigestProducer(medicine2));
    }
}
