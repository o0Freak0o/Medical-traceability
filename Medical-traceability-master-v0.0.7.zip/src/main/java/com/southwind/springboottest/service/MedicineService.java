package com.southwind.springboottest.service;

import com.southwind.springboottest.entity.Medicine;
import com.southwind.springboottest.page.PageRequest;
import com.southwind.springboottest.page.PageResult;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MedicineService {

     /**
      * 新药材的入库操作
      * @param in_med
      * @return
      */
     int InUpdate(Medicine in_med);

     /**
      * 已有药材的出库操作
      * @param out_med
      * @return
      */
     int OutUpdate(Medicine out_med);

     /**
      * 根据id查询
      * @param id
      * @return
      */
     Medicine findById(Integer id);

     /**
      * 根据溯源码查询
      * @param tra_code
      * @return
      */
     Medicine findByTra_code(long tra_code);

     /**
      * 查询所有
      * @return
      */
     List<Medicine> findAll();

     /**
      * 根据id删除
      * @param id
      * @return
      */
     int deleteById(Integer id);

     /**
      * 进行多字段数据修改
      * @param medicine
      * @return
      */
     int Update(Medicine medicine);

     /**
      * 分页查找
      * @return
      */
     PageResult findPage(PageRequest pageRequest);


}
