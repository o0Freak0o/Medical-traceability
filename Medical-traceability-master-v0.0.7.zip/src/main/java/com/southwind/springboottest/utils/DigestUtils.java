package com.southwind.springboottest.utils;

import com.southwind.springboottest.entity.Medicine;

import java.io.IOException;

public class DigestUtils {

    public static String DigestProducer(Medicine medicine)
    {
        String data=medicine.toString();
        try {
            return SM3Encoder.byteArrayToHexString(SM3Encoder.hash(data.getBytes()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "error";
    }
}
