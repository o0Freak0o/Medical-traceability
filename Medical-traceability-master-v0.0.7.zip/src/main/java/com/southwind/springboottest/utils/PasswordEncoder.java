package com.southwind.springboottest.utils;

import com.southwind.springboottest.entity.Medicine;

import java.io.IOException;

public class PasswordEncoder {
    public static String Encrypt(String password)
    {

        try {
            return SM3Encoder.byteArrayToHexString(SM3Encoder.hash(password.getBytes()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "error";
    }
}
