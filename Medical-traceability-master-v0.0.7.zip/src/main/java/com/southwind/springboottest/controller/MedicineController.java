package com.southwind.springboottest.controller;


import com.southwind.springboottest.entity.Medicine;
import com.southwind.springboottest.http.HttpResult;
import com.southwind.springboottest.page.PageRequest;
import com.southwind.springboottest.service.MedicineService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(value="/medicine",tags = "药材相关操作")
@RestController
@RequestMapping("/medicine")
public class MedicineController {

    @Autowired
    private MedicineService medicineService;

    @ApiOperation(value = "查找全部药材数据")
    @GetMapping("/findAll")
    public HttpResult findAll(){
        return HttpResult.ok(medicineService.findAll());
    }

    @ApiOperation(value = "根据ID查找药材")
    @GetMapping("/findById/{id}")
    public HttpResult findById(@PathVariable("id") Integer id){
        return HttpResult.ok(medicineService.findById(id));
    }

    @ApiOperation(value = "根据溯源码查找药材")
    @GetMapping("/findByTra_code/{tra_code}")
    public HttpResult findById(@PathVariable("tra_code") long tra_code){
        return HttpResult.ok(medicineService.findByTra_code(tra_code));
    }

    @ApiOperation(
            value = "药材数据修改",
            notes = "传入需要修改的药材ID及需要修改的数据，不修改的数据置空值"
    )
    @PutMapping("/update")
    public HttpResult update(@RequestBody Medicine medicine){
        return HttpResult.ok(medicineService.Update(medicine));
    }

    @ApiOperation(value = "根据药材ID删除数据")
    @DeleteMapping("/deleteById/{id}")
    public HttpResult deleteById(@PathVariable("id") Integer id){
        return HttpResult.ok(medicineService.deleteById(id));
    }

    /**
     * 药材的入库变动，实现库存数量与入库时间的更新
     * @param modify
     * @return
     */
    @ApiOperation(
            value = "药材入库",
            notes = "传入药材除id、生产批号、入库时间、出库时间以外的全部信息"
    )
    @PostMapping(path="/in",consumes = "application/json")
    public HttpResult In_Modify(@RequestBody Medicine modify)
    {
        return HttpResult.ok(medicineService.InUpdate(modify));
    }

    /**
     * 药材的出库变动，实现库存数量与出库时间的更新
     * @param modify
     * @return
     */
    @ApiOperation(
            value = "药材出库",
            notes = "只需要传目标药材的ID与出库数量即可，其他参数自动处理"
    )
    @PatchMapping(path="/out",consumes = "application/json")
    public HttpResult Out_Modify(@RequestBody Medicine modify)
    {
        return HttpResult.ok(medicineService.OutUpdate(modify));
    }

    /**
     * 分页查找
     * @param pageRequest
     * @return
     */
    @ApiOperation(
            value = "分页查找",
            notes = "传入页码与每页数量"
    )
    @PostMapping(value="/findPage")
    public HttpResult findPage(@RequestBody PageRequest pageRequest) {
        return HttpResult.ok(medicineService.findPage(pageRequest));
    }
}
