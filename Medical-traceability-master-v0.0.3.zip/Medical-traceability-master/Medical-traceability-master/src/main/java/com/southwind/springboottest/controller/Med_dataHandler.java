package com.southwind.springboottest.controller;

import com.southwind.springboottest.dao.Med_dataDao;
import com.southwind.springboottest.entity.Med_data;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

@Api(value="/medicine",tags = "药材相关操作")
@RestController
@RequestMapping("/medicine")
public class Med_dataHandler {

    @Autowired
    private Med_dataDao med_dataDao;

    @ApiOperation(value = "查找全部药材数据")
    @GetMapping("/findAll")
    public List<Med_data> findAll(){
        return med_dataDao.findAll();
    }

    @ApiOperation(value = "保存药材数据")
    @PostMapping("/save")
    public String save(@RequestBody Med_data med_data){
        med_dataDao.save(med_data);
        return "true";
    }

    @ApiOperation(value = "根据ID查找药材")
    @GetMapping("/findById/{id}")
    public Med_data findById(@PathVariable("id") Integer id){
        return med_dataDao.findById(id);
    }


    @ApiOperation(
            value = "药材数据修改",
            notes = "传入需要修改的药材ID及需要修改的数据，不修改的数据置空值"
    )
    @PutMapping("/update")
    public String update(@RequestBody Med_data med_data){
        Med_data update = med_dataDao.findById(med_data.getId());
        if(med_data.getName()!=null)
        {
            update.setName(med_data.getName());
        }
        if(med_data.getAmount()!=null)
        {
            update.setAmount(med_data.getAmount());
        }
        if(med_data.getIn_time()!=null)
        {
            update.setIn_time(med_data.getIn_time());
        }
        if(med_data.getOut_time()!=null)
        {
            update.setOut_time(med_data.getOut_time());
        }
        if(med_data.getDistribution()!=null)
        {
            update.setDistribution(med_data.getDistribution());
        }
        med_dataDao.Update(update);

        return "true";
    }

    @ApiOperation(value = "根据药材ID删除数据")
    @DeleteMapping("/deleteById/{id}")
    public void deleteById(@PathVariable("id") Integer id){
        med_dataDao.deleteById(id);
    }

    /**
     * 药材的入库变动，实现库存数量与入库时间的更新
     * @param id
     * @param modify
     * @return
     */
    @ApiOperation(
            value = "药材入库",
            notes = "只需要传目标药材的ID与入库数量即可，其他参数自动处理"
    )
    @PatchMapping(path="in/{id}",consumes = "application/json")
    public String In_Modify(@PathVariable("id")Integer id,@RequestBody Med_data modify)
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        Med_data med_data=med_dataDao.findById(id);
        if(modify.getAmount()!=null)
        {
            med_data.setAmount((med_data.getAmount()+modify.getAmount()));
        }
        med_data.setIn_time(formattedDate);
        med_dataDao.InUpdate(med_data);
        return "true";
    }

    /**
     * 药材的出库变动，实现库存数量与出库时间的更新
     * @param id
     * @param modify
     * @return
     */
    @ApiOperation(
            value = "药材出库",
            notes = "只需要传目标药材的ID与出库数量即可，其他参数自动处理"
    )
    @PatchMapping(path="out/{id}",consumes = "application/json")
    public String Out_Modify(@PathVariable("id")Integer id,@RequestBody Med_data modify)
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        Med_data med_data=med_dataDao.findById(id);
        if(modify.getAmount()!=null)
        {
            med_data.setAmount((med_data.getAmount()-modify.getAmount()));
            if(med_data.getAmount()<0)
            {
                return "false";
            }
        }
        med_data.setOut_time(formattedDate);
        med_dataDao.OutUpdate(med_data);
        return "true";
    }
}
