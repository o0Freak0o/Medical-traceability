package com.southwind.springboottest.dao;

import com.southwind.springboottest.entity.Med_data;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface Med_dataDao {

    @Select("select * from med_data")
    List<Med_data> findAll();

    @Select("select * from med_data where id=#{id}")
    Med_data findById(Integer id);

    @Insert("insert into med_data (name,distribution,amount,In_time) " +
            "values (#{name},#{distribution},#{amount},#{In_time})")
    void save(Med_data med_data);

    @Delete("delete from med_data where id=#{id}")
    void deleteById(Integer id);

    @Update("update med_data set " +
            "name=#{name}," +
            "distribution=#{distribution}," +
            "amount=#{amount}," +
            "In_time=#{In_time}," +
            "Out_time=#{Out_time} " +
            "where id=#{id}")
    void Update(Med_data med_data);

    @Update("update med_data set " +
            "name=#{name}," +
            "distribution=#{distribution}," +
            "amount=#{amount}," +
            "In_time=#{In_time} " +
            "where id=#{id}")
    void InUpdate(Med_data med_data);

    @Update("update med_data set " +
            "name=#{name}," +
            "distribution=#{distribution}," +
            "amount=#{amount}," +
            "Out_time=#{Out_time} " +
            "where id=#{id}")
    void OutUpdate(Med_data med_data);

}
