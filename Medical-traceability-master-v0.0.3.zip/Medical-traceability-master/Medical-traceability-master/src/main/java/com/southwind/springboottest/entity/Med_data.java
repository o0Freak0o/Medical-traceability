package com.southwind.springboottest.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Med_data {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String distribution;
    private Integer amount;
    private String In_time;
    private String Out_time;


    public Med_data(String name, String distribution, Integer amount, String in_time, String out_time) {
        this.name = name;
        this.distribution = distribution;
        this.amount = amount;
        In_time = in_time;
        Out_time = out_time;
    }

    public Med_data(String name, String distribution, Integer amount, String in_time) {
        this.name = name;
        this.distribution = distribution;
        this.amount = amount;
        In_time = in_time;
    }

}
