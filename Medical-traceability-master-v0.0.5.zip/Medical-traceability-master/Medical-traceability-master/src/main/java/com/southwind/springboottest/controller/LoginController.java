package com.southwind.springboottest.controller;

import com.southwind.springboottest.bean.LoginBean;
import com.southwind.springboottest.entity.User;
import com.southwind.springboottest.http.HttpResult;
import com.southwind.springboottest.security.JwtAuthenticatioToken;
import com.southwind.springboottest.service.UserService;
import com.southwind.springboottest.utils.PasswordUtils;
import com.southwind.springboottest.utils.SecurityUtils;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Objects;


@Api(value="/login",tags = "登录操作")
@RestController
public class LoginController {

    @Autowired
    private UserService userService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @PostMapping(value = "/login")
    public HttpResult login(@RequestBody LoginBean loginBean, HttpServletRequest request)
    {
        String username = loginBean.getName();
        String password = loginBean.getPassword();
        User user = userService.findByName(username);
        if (user == null) {
            return HttpResult.error("账号不存在");
        }
        if (!Objects.equals(userService.findByName(username).getPassword(),password)) {
            return HttpResult.error("密码不正确");
        }
        JwtAuthenticatioToken token = SecurityUtils.login(request, username, password, authenticationManager);
        return HttpResult.ok(token);

    }
}
