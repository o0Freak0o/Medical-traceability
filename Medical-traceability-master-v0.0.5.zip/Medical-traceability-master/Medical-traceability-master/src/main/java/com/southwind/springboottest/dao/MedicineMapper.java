package com.southwind.springboottest.dao;

import com.southwind.springboottest.entity.Medicine;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface MedicineMapper {

    @Select("select * from medicine")
    List<Medicine> findAll();

    @Select("select * from medicine where id=#{id}")
    Medicine findById(Integer id);

    @Select("select * from medicine where tra_code=#{tra_code}")
    Medicine findByTra_code(long tra_code);

    @Insert("insert into medicine (name,farmer_id,producer_id,category,purch_time,tra_code,amount,In_time) " +
            "values (#{name},#{farmer_id},#{producer_id},#{category},#{purch_time},#{tra_code},#{amount},#{In_time})")
    int save(Medicine medicine);

    @Delete("delete from medicine where id=#{id}")
    int deleteById(Integer id);

    @Update("update medicine set " +
            "name=#{name}," +
            "farmer_id=#{farmer_id}," +
            "producer_id=#{producer_id}," +
            "category=#{category}," +
            "purch_time=#{purch_time}," +
            "tra_code=#{tra_code}," +
            "amount=#{amount}," +
            "In_time=#{In_time}," +
            "Out_time=#{Out_time} " +
            "where id=#{id}")
    int Update(Medicine medicine);

    @Update("update medicine set " +
            "name=#{name}," +
            "distribution=#{distribution}," +
            "amount=#{amount}," +
            "In_time=#{In_time} " +
            "where id=#{id}")
    int InUpdate(Medicine medicine);

    @Update("update medicine set " +
            "name=#{name}," +
            "distribution=#{distribution}," +
            "amount=#{amount}," +
            "Out_time=#{Out_time} " +
            "where id=#{id}")
    int OutUpdate(Medicine medicine);

    @Select("select * from medicine")
    List<Medicine> findPage();

}
