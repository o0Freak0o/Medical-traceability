package com.southwind.springboottest.utils;

public class Tra_codeUtils {

    public static long code()
    {
        return System.currentTimeMillis();
    }

}
