package com.southwind.springboottest.repository;

import com.southwind.springboottest.dao.RoleMapper;
import com.southwind.springboottest.dao.UserMapper;
import com.southwind.springboottest.entity.Role;
import com.southwind.springboottest.entity.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.persistence.Table;

@SpringBootTest
@RunWith(SpringRunner.class)
public class User_RoleTest {

    @Autowired
    UserMapper userMapper;

    @Autowired
    RoleMapper roleMapper;

    @Test
    public void UserTest()
    {
        userMapper.save(new User(
                "zxc","kkk",
                "123456","adhiuqh123",
                "abc@163.com","13130847823",2));

    }

    @Test
    public void RoleTest()
    {
        roleMapper.save(new Role("管理员"));
        roleMapper.save(new Role("普通用户"));
    }

    @Test
    public void User_Role()
    {
        System.out.println(roleMapper.findAll().toString());
        System.out.println(userMapper.findAll().toString());
        System.out.println(userMapper.findById(1));
        System.out.println(roleMapper.findById(1));
    }

    @Test
    public void UserUpdate()
    {
        User user=userMapper.findById(1);
        user.setMobile("10086");
        user.setPassword("10101010");
        user.setRole_id(2);
        userMapper.Update(user);
    }

    @Test
    public void DeleteById()
    {
        userMapper.deleteById(1);
    }

    @Test
    public void RoleUpdate()
    {
        Role role=roleMapper.findById(1);
        role.setName("超级管理员");
        roleMapper.Update(role);
    }
}
