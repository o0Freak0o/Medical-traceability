package com.southwind.springboottest.repository;

import com.southwind.springboottest.dao.MedicineMapper;
import com.southwind.springboottest.entity.Medicine;

import com.southwind.springboottest.service.MedicineService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

@SpringBootTest
@RunWith(SpringRunner.class)
public class MedicineDaoTest {

    @Autowired
    MedicineService medicineService;

    @Test
    public void saveTest()
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
//        medicineMapper.save(new Medicine("人参","西藏",100,formattedDate,formattedDate));
        Medicine medicine=new Medicine(24,123,"黄芪","中药",formattedDate,2000,formattedDate);
        medicineService.InUpdate(medicine);
    }

    @Test
    public void findAllTest()
    {
        List<Medicine> list= medicineService.findAll();
        System.out.println(list);
    }

    @Test
    public void DeleteByIDTest()
    {

        medicineService.deleteById(1);
    }

    @Test
    public void UpdateAndFindByIdTest()
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        Medicine medicine = medicineService.findById(2);
        medicine.setAmount(5000);
        medicine.setOut_time(formattedDate);
        medicineService.Update(medicine);
    }

    @Test
    public void InUpdateTest()
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        Medicine medicine = medicineService.findById(2);
        medicine.setIn_time(formattedDate);
        medicineService.InUpdate(medicine);
    }

    @Test
    public void OutUpdateTest()
    {
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        String formattedDate = dateFormat.format(date);
        Medicine medicine = medicineService.findById(3);
        medicine.setOut_time(formattedDate);
        medicineService.OutUpdate(medicine);
    }



}
